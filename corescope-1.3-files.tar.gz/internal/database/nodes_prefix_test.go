package database_test

import "testing"

func TestMatchNodesByPrefix_CaseInsensitiveKeepsCallerKey(t *testing.T) {
	db := newDB(t)
	seedNodes(t, db,
		nodeAt("aa01", "Alpha", "repeater", nodesNow),
		nodeAt("aa02", "Bravo", "room", nodesNow),
		nodeAt("bb03", "Charlie", "repeater", nodesNow),
	)

	matches, err := db.MatchNodesByPrefix(t.Context(), []string{"AA01", "Aa", "bb03", "BB03", "", "  "})
	if err != nil {
		t.Fatal(err)
	}
	if m := matches["AA01"]; m.Matches != 1 || m.Pubkey != "aa01" || m.Name != "Alpha" {
		t.Errorf("AA01: want one match, Alpha, got %+v", m)
	}
	if m := matches["Aa"]; m.Matches != 2 {
		t.Errorf("Aa: want 2 matches, got %+v", m)
	}
	if m := matches["bb03"]; m.Matches != 1 || m.Pubkey != "bb03" {
		t.Errorf("bb03: want one match, got %+v", m)
	}
	if m := matches["BB03"]; m.Matches != 1 || m.Pubkey != "bb03" {
		t.Errorf("BB03: want the same match under the caller's spelling, got %+v", m)
	}
	if _, ok := matches[""]; ok {
		t.Error("a blank prefix must be skipped, not match every node")
	}
	if _, ok := matches["  "]; ok {
		t.Error("a whitespace prefix must be skipped, not match every node")
	}
	if len(matches) != 4 {
		t.Errorf("want 4 entries (AA01, Aa, bb03, BB03), got %d: %+v", len(matches), matches)
	}
}
