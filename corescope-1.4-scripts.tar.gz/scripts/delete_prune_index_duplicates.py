#!/usr/bin/env python3
"""Delete the standalone prune-index tests that TestPruneDeletesCanUseTheirIndex replaces.

Run from the repo root. For each test it removes the function and the comment
block directly above it, then reports any import the file no longer uses.
"""
import re
import sys

TARGETS = {
    'cmd/ingestor/client_regions_test.go': ['TestPruneClientDeclaredRegionsUsesIndex'],
    'cmd/ingestor/client_reception_test.go': ['TestPruneClientRxObservationsUsesIndex', 'TestClientReceptionsRetentionUsesRxAtIndex'],
}

def remove_func(src, name):
    m = re.search(r'^func ' + re.escape(name) + r'\(', src, re.M)
    if not m:
        sys.exit(f"{name}: not found")
    start = m.start()
    lines_before = src[:start].split('\n')
    # lines_before ends with '' (the text before the func's first character).
    i = len(lines_before) - 1
    while i > 0 and lines_before[i - 1].startswith('//'):
        i -= 1
    start = len('\n'.join(lines_before[:i])) + (1 if i > 0 else 0)
    end = src.index('\n}\n', m.start()) + 3
    return src[:start] + src[end:].lstrip('\n')

for path, names in TARGETS.items():
    text = open(path).read()
    for name in names:
        text = remove_func(text, name)
    open(path, 'w').write(text)
    block = re.search(r'import \((.*?)\n\)', text, re.S)
    body = text[block.end():]
    kept = []
    for line in block.group(1).split('\n'):
        spec = line.strip().split('//')[0].strip()
        if spec and not spec.startswith('_'):
            parts = spec.split()
            quoted = parts[-1].strip('"')
            segments = quoted.split('/')
            ident = parts[0] if len(parts) == 2 else (segments[-2] if re.fullmatch(r'v\d+', segments[-1]) else segments[-1])
            if not re.search(r'\b' + re.escape(ident) + r'\.', body):
                print(f"{path}: removed unused import {quoted}")
                continue
        kept.append(line)
    text = text[:block.start(1)] + '\n'.join(kept) + text[block.end(1):]
    open(path, 'w').write(text)
    print(f"{path}: removed {', '.join(names)}")
