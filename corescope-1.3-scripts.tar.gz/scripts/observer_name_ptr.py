#!/usr/bin/env python3
"""Wrap Name: values in database.ObserverInput literals with ptr(...).

Run from the repo root:  python3 observer_name_ptr.py
"""
import pathlib, re, sys

NAME = re.compile(r'(\bName:\s*)([^,}\n]+?)(\s*[,}])')

def block_end(s, i):
    depth = 0
    while i < len(s):
        c = s[i]
        if c == '"':
            i += 1
            while s[i] != '"':
                i += 2 if s[i] == '\\' else 1
        elif c == '`':
            i = s.index('`', i + 1)
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise SystemExit("unbalanced braces")

changed = 0
for path in list(pathlib.Path('cmd').rglob('*_test.go')) + list(pathlib.Path('internal').rglob('*_test.go')):
    s = path.read_text()
    if 'ObserverInput{' not in s:
        continue
    out, pos = [], 0
    for m in re.finditer(r'\bObserverInput\{', s):
        if m.start() < pos:
            continue
        start = m.end() - 1
        end = block_end(s, start)
        block = s[start:end + 1]
        new = NAME.sub(lambda n: n.group(1) + 'ptr(' + n.group(2) + ')' + n.group(3)
                       if not n.group(2).startswith('ptr(') else n.group(0), block)
        out.append(s[pos:start]); out.append(new); pos = end + 1
        if new != block:
            changed += 1
    out.append(s[pos:])
    path.write_text(''.join(out))
print(f"{changed} ObserverInput literals updated")
