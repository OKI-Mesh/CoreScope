#!/usr/bin/perl
# Run from the repo root: perl ingestor_tests.pl cmd/ingestor/*_test.go
# 1. Upsert* calls: wrap the name argument in ptr(...).
# 2. BuildPacketData: drop the region argument.
undef $/;
for my $f (@ARGV) {
    open my $in, '<', $f or die "$f: $!";
    my $s = <$in>; close $in;
    my $o = $s;
    my $id = qr/(?:fmt\.Sprintf\([^)]*\)|[^,]+)/;
    $s =~ s/(\.UpsertObserver(?:At|Retained)?\(\s*(?:ctx|testCtx\(t\)),\s*$id,\s*)("[^"]*"|[A-Za-z_][\w.]*)(\s*,)/$1ptr($2)$3/g;
    $s =~ s/(BuildPacketData\((?:&MQTTPacketMessage\{[^}]*\}|\w+),\s*[^,]+,\s*(?:"[^"]*"|\w+)),\s*(?:"[^"]*"|\w+)(,\s*(?:nil|regionKeySetFromKeys\([^)]*\)|\w+)\))/$1$2/g;
    if ($s ne $o) { open my $out, '>', $f or die; print $out $s; close $out; print "updated $f\n"; }
}
