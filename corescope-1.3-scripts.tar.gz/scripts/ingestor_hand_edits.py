#!/usr/bin/env python3
"""Edits to cmd/ingestor/store_test.go for the removed PacketData fields.

Run from the repo root after ingestor_tests.pl.
"""
p = 'cmd/ingestor/store_test.go'
s = open(p).read()
i = s.index("func TestBuildPacketDataRegionFromPayload")
j = s.index("// TestUpdateNodeDefaultScope_EmptyScopeIsNoop")
s = s[:i] + s[j:]
for old, new in [
    ('''	if pkt.ObserverName != "test-observer" {
		t.Errorf("observerName=%s", pkt.ObserverName)
	}
''', ''),
    ('''		Timestamp: "2026-05-16T10:00:00Z",
''', ''),
]:
    if old not in s:
        raise SystemExit("expected text not found:\n" + old)
    s = s.replace(old, new)
open(p, 'w').write(s)
